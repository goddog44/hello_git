# from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.views import APIView

from API.models import Rest
from API.serializers import RestSerializer
from rest_framework import status

# Create your views here.
class RestList(APIView):
        def get(self, request):
            APIs = Rest.objects.all()
            serializer = RestSerializer(APIs, many=True )
            return Response(serializer.data)



        def post(self, request):
            serializer = RestSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status= status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
