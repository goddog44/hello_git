from Django.urls import path

from API import views

urlpatterns = [
    path('', views.RestList.as_view())
]