from rest_framework import serializers

from API.models import Rest


class RestSerializer(serializers.ModelSerializer):
    class Meta:
            model = Rest
            fields = "__all__"